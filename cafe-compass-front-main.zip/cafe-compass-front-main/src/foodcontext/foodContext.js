import { createContext } from "react";

const foodContext = createContext();

export default foodContext;